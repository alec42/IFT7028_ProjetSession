import openscad_export


#openscad_export.export_to_svg("Test\main.scad","Test\output.svg")
#openscad_export.export_to_dxf("Test\curvetest_1.scad","Test\output.dxf")
# openscad_export.generate_isometric_view("Test\main.scad","Test\iso2.png")
# openscad_export.generate_isometric_view("Test/main.scad","Test/iso2.png")
