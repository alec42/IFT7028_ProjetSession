# IFT-7028-Prod-Asmb
Projet de session dans le cadre du cours IFT-7028
