library(reticulate)
library(tidyverse)
# setwd("./3-Production-Assemblage/")
packages_install <- pull(read_table("packages_py.txt", col_names = "packages"), packages) |> as.list.data.frame()
reticulate::py_install(packages = packages_install, pip = T)

reticulate::source_python("Production/ErpCommunication.py")

prod <- GetProductionInformation(currentOrderId = '97297049', firstPannelId = 89, firstPieceId = 89)
PanneauDetail <- prod[[1]] |> as_tibble() |> mutate(across(c(PanneauID, PieceID, PanneauType), unlist))

tibble(
    PieceID = as.numeric(unlist(prod[[2]])[seq(1,length(prod[[2]])*2,2)]),
    FichierDecoupe = unlist(prod[[2]])[seq(2,length(prod[[2]])*2,2)]
) |>
    left_join(PanneauDetail, by="PieceID") |>
    group_by(PanneauID) |>
    select(PanneauID, FichierDecoupe) |> distinct()
assembly <- GetAssemblyInformation(currentOrderId = '97297049')
assembly
